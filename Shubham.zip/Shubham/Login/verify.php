<?php
    session_start();

    require '../db.php';

    if(isset($_GET['email']) && !empty($_GET['email']) AND isset($_GET['hash']) && !empty($_GET['hash']))
    {
        $email = dataFilter($_GET['email']);
        $hash = dataFilter($_GET['hash']);

        // First try farmer table
        $es = mysqli_real_escape_string($conn, $email);
        $hs = mysqli_real_escape_string($conn, $hash);

        $sql = "SELECT * FROM farmer WHERE femail='$es' AND fhash='$hs' AND factive='0'";
        $result = mysqli_query($conn, $sql);

        if ($result && $result->num_rows > 0)
        {
            // Activate farmer
            $sql = "UPDATE farmer SET factive=1 WHERE femail='$es'";
            mysqli_query($conn, $sql);
            $_SESSION['message'] = "Your account has been activated!";
            $_SESSION['Active'] = 1;
            header("location: success.php");
            exit();
        }

        // Then try buyer table
        $sql = "SELECT * FROM buyer WHERE bemail='$es' AND bhash='$hs' AND bactive='0'";
        $result = mysqli_query($conn, $sql);

        if ($result && $result->num_rows > 0)
        {
            // Activate buyer
            $sql = "UPDATE buyer SET bactive=1 WHERE bemail='$es'";
            mysqli_query($conn, $sql);
            $_SESSION['message'] = "Your account has been activated!";
            $_SESSION['Active'] = 1;
            header("location: success.php");
            exit();
        }

        // Not found or already active
        $_SESSION['message'] = "Account has already been activated or the URL is invalid!";
        header("location: error.php");
        exit();
    }
     else
    {
        $_SESSION['message'] = "Invalid credentials provided for account verification!";
        header("location: error.php");
    }

    function dataFilter($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

?>
