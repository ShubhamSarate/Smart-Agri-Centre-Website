<?php
    session_start();

    if ( $_SESSION['logged_in'] != 1 )
    {
      $_SESSION['message'] = "You must log in before viewing your profile page!";
      header("location: error.php");
    }
    else
    {

       $email =  $_SESSION['Email'];
       $name =  $_SESSION['Name'];
       $user =  $_SESSION['Username'];
       $mobile = $_SESSION['Mobile'];
        // Refresh active status from DB to avoid stale session values
        require '../db.php';
        $active = isset($_SESSION['Active']) ? $_SESSION['Active'] : 0;
        if (isset($_SESSION['Category'])) {
            $category = $_SESSION['Category'];
            if ($category == 1) {
                $es = mysqli_real_escape_string($conn, $user);
                $res = mysqli_query($conn, "SELECT factive FROM farmer WHERE fusername='$es' LIMIT 1");
                if ($res && $row = $res->fetch_assoc()) {
                    $active = (int)$row['factive'];
                    $_SESSION['Active'] = $active;
                }
            } else {
                $es = mysqli_real_escape_string($conn, $user);
                $res = mysqli_query($conn, "SELECT bactive FROM buyer WHERE busername='$es' LIMIT 1");
                if ($res && $row = $res->fetch_assoc()) {
                    $active = (int)$row['bactive'];
                    $_SESSION['Active'] = $active;
                }
            }
        }
    }
?>

<!DOCTYPE html>
    <html >
     <head>
        <title>Krishna Sheti Seva Kendra</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="../bootstrap\css\bootstrap.min.css" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="../bootstrap\js\bootstrap.min.js"></script>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="../js/jquery.min.js"></script>
		<script src="../js/skel.min.js"></script>
		<script src="../js/skel-layers.min.js"></script>
		<script src="../js/init.js"></script>
		<link rel="stylesheet" href="../css/skel.css" />
        <link rel="stylesheet" href="../css/style.css" />
        <link rel="stylesheet" href="../css/style-xlarge.css" />
        <link rel="stylesheet" href="../css/global-style.css" />
        <link rel="stylesheet" href="../css/font-awesome.min.css">
        <style>
            /* Match myCart page visual: gradient background, transparent wrapper, card-like message box */
            body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
            .wrapper { background: transparent !important; }
            .message-box {
                background: white;
                border-radius: 8px;
                padding: 18px;
                margin: 20px auto;
                max-width: 720px;
                box-shadow: 0 6px 18px rgba(0,0,0,0.10);
                color: #222;
            }
            .button, .button.special, a.button {
                display: inline-flex !important;
                align-items: center;
                justify-content: center;
                text-align: center;
                gap: 8px;
            }
            header.major h2 { color: #fff; }

            /* Center and stack banner content for clean alignment */
            #banner .container {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                text-align: center;
                gap: 14px;
            }

            /* Ensure message box and button row don't span full width unexpectedly */
            #banner .message-box { width: 100%; max-width: 720px; }
            #banner .row.uniform { display: flex; justify-content: center; gap: 12px; width: 100%; max-width: 720px; }
            #banner .row.uniform > div { flex: 1 1 240px; max-width: 320px; }
            @media (max-width: 720px) { #banner .row.uniform > div { max-width: 100%; flex: 1 1 100%; } }
        </style>
    </head>

    <body>
        <?php
            require 'menu.php';
        ?>

        <section id="banner" class="wrapper">
            <div class="container">
                <header class="major">
                    <h2>Welcome</h2>
                </header>
                <div class="message-box">
                <?php
                    if ( isset($_SESSION['message']) )
                    {
                        echo $_SESSION['message'];
                        unset( $_SESSION['message'] );
                    }
                ?>
                </div>

                <?php
                    // Email verification check removed
                ?>
                  <h2><?php echo $name; ?></h2>
                  <p><?= $email ?></p>

                 <?php if($_SESSION['Category'] == 1): ?>
                    <div class="row uniform">
                        <div class="6u 12u$(xsmall)">
                            <a href=../profileView.php class="button special">My Profile</a>
                        </div>
                        <div class="6u 12u$(xsmall)">
                            <a href="logout.php" class="button special">LOG OUT</a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row uniform">
                        <div class="6u 12u$(xsmall)">
                            <a href=../profileView.php class="button special">Your Profile</a>
                        </div>
                        <div class="6u 12u$(xsmall)">
                            <a href="logout.php" class="button special">LOG OUT</a>
                        </div>
                    </div>

                <?php endif; ?>


    </body>
</html>
