<?php
    session_start();

    require '../db.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST')
    {
        $user = dataFilter($_POST['uname'] ?? '');
        $currPass = $_POST['currPass'] ?? '';
        $newPass = $_POST['newPass'] ?? '';
        $conNewPass = $_POST['conNewPass'] ?? '';
        $newHash = dataFilter( md5( rand(0,1000) ) );

        // Determine table/columns based on session Category
        $category = isset($_SESSION['Category']) ? $_SESSION['Category'] : null;

        if ($category === 1) {
            $table = 'farmer';
            $usernameCol = 'fusername';
            $passCol = 'fpassword';
            $hashCol = 'fhash';
        } else {
            $table = 'buyer';
            $usernameCol = 'busername';
            $passCol = 'bpassword';
            $hashCol = 'bhash';
        }

        // fetch user row by username
        $euser = mysqli_real_escape_string($conn, $user);
        $sql = "SELECT * FROM $table WHERE $usernameCol='$euser'";
        $result = mysqli_query($conn, $sql);
        $num_rows = mysqli_num_rows($result);

        if($num_rows == 0)
        {
            $_SESSION['message'] = "Invalid User Credentials!";
            header("location: ../Login/error.php");
            exit();
        }

        $User = $result->fetch_assoc();

        if(password_verify($currPass, $User[$passCol]))
        {
            if($newPass === $conNewPass)
            {
                $hashed = password_hash($conNewPass, PASSWORD_BCRYPT);
                $currHash = isset($_SESSION['Hash']) ? $_SESSION['Hash'] : '';

                $enew = mysqli_real_escape_string($conn, $hashed);
                $enewHash = mysqli_real_escape_string($conn, $newHash);

                // update password and hash by matching current hash if available, else by id
                if (!empty($currHash)) {
                    $ecurrHash = mysqli_real_escape_string($conn, $currHash);
                    $sql = "UPDATE $table SET $passCol='$enew', $hashCol='$enewHash' WHERE $hashCol='$ecurrHash'";
                } else {
                    // fallback: update by username
                    $sql = "UPDATE $table SET $passCol='$enew', $hashCol='$enewHash' WHERE $usernameCol='$euser'";
                }

                $result = mysqli_query($conn, $sql);

                if($result)
                {
                    $_SESSION['message'] = "Password changed Successfully!";
                    header("location: ../Login/success.php");
                    exit();
                }
                else
                {
                    $_SESSION['message'] = "Error occurred while changing password<br>Please try again!";
                    header("location: ../Login/error.php");
                    exit();
                }
            } else {
                $_SESSION['message'] = "New password and confirm password do not match.";
                header("location: ../Login/error.php");
                exit();
            }
        }
        else
        {
            $_SESSION['message'] = "Invalid current User Credentials!";
            header("location: ../Login/error.php");
            exit();
        }
    }

    function dataFilter($data)
    {
    	$data = trim($data);
     	$data = stripslashes($data);
    	$data = htmlspecialchars($data);
      	return $data;
    }

?>
