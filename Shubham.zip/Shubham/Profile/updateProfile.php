<?php
    session_start();
    require '../db.php';

    // Ensure `buyer` table has `bcity` and `bpincode` columns to avoid SQL errors
    $colCheckSql = "SHOW COLUMNS FROM buyer LIKE 'bcity'";
    $colRes = @mysqli_query($conn, $colCheckSql);
    if (!$colRes || mysqli_num_rows($colRes) == 0) {
        @mysqli_query($conn, "ALTER TABLE buyer ADD COLUMN bcity VARCHAR(255) DEFAULT ''");
    }
    $colCheckSql = "SHOW COLUMNS FROM buyer LIKE 'bpincode'";
    $colRes = @mysqli_query($conn, $colCheckSql);
    if (!$colRes || mysqli_num_rows($colRes) == 0) {
        @mysqli_query($conn, "ALTER TABLE buyer ADD COLUMN bpincode VARCHAR(50) DEFAULT ''");
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // Sanitize incoming data
        $name = dataFilter($_POST['name'] ?? '');
        $mobile = dataFilter($_POST['mobile'] ?? '');
        $user = dataFilter($_POST['uname'] ?? '');
        $email = dataFilter($_POST['email'] ?? '');
    $section = dataFilter($_POST['section'] ?? '');
    $addr = dataFilter($_POST['addr'] ?? '');
    $city = dataFilter($_POST['city'] ?? '');
    $pincode = dataFilter($_POST['pincode'] ?? '');
        $post = dataFilter($_POST['post'] ?? '');
        $year = dataFilter($_POST['year'] ?? '');
        $edu = dataFilter($_POST['edu'] ?? '');

        // Update session values for UI
        $_SESSION['Email'] = $email;
        $_SESSION['Name'] = $name;
        $_SESSION['Username'] = $user;
        // use Mobile key used in other pages
        $_SESSION['Mobile'] = $mobile;
    $_SESSION['Section'] = $section;
    $_SESSION['Addr'] = $addr;
    $_SESSION['City'] = $city;
    $_SESSION['Pincode'] = $pincode;
        $_SESSION['Post'] = $post;
        $_SESSION['Edu'] = $edu;
        $_SESSION['Year'] = $year;

        // Determine which DB table to update based on Category (1 = farmer/user, 0 = buyer/admin)
        $id = isset($_SESSION['id']) ? $_SESSION['id'] : 0;
        $category = isset($_SESSION['Category']) ? $_SESSION['Category'] : null;

        // Escape values for query
        $ename = mysqli_real_escape_string($conn, $name);
        $euser = mysqli_real_escape_string($conn, $user);
        $emobile = mysqli_real_escape_string($conn, $mobile);
        $eemail = mysqli_real_escape_string($conn, $email);

        if ($category === 1)
        {
            // Update farmer table (includes address)
            $eaddr = mysqli_real_escape_string($conn, $addr);
            $sql = "UPDATE farmer SET fname='$ename', fusername='$euser', fmobile='$emobile', femail='$eemail', faddress='$eaddr' WHERE fid='$id'";
        }
        else
        {
            // Update buyer table (includes address, city, pincode)
            $eaddr = mysqli_real_escape_string($conn, $addr);
            $ecity = mysqli_real_escape_string($conn, $city);
            $epincode = mysqli_real_escape_string($conn, $pincode);
            $sql = "UPDATE buyer SET bname='$ename', busername='$euser', bmobile='$emobile', bemail='$eemail', baddress='$eaddr', bcity='$ecity', bpincode='$epincode' WHERE bid='$id'";
        }

        $result = mysqli_query($conn, $sql);
        if($result)
        {
            $_SESSION['message'] = "Profile Updated successfully !!!";
            header("Location: ../profileView.php");
            exit();
        }
        else
        {
            // Log or show DB error for debugging
            $dbError = mysqli_error($conn);
            $_SESSION['message'] = "There was an error in updating your profile! Error: " . htmlspecialchars($dbError);
            header("Location: ../Login/error.php");
            exit();
        }
    }

function dataFilter($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


?>
