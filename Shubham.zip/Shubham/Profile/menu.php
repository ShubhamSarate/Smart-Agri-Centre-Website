<?php
// Wrapper for root menu: include the canonical header fragment.
require_once __DIR__ . '/../menu.php';
?>