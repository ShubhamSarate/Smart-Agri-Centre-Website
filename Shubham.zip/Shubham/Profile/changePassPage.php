<?php
    if (session_status() == PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Change Password</title>
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .password-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            max-width: 480px;
            width: 100%;
            animation: slideUp 0.5s ease-out;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .password-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px 25px;
            text-align: center;
        }
        
        .password-header h3 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .password-header i {
            font-size: 28px;
        }
        
        .password-content {
            padding: 35px 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }
        
        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        .input-with-toggle { position: relative; }
        .input-with-toggle .toggle-pass {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            color: #667eea;
            font-size: 16px;
            cursor: pointer;
            padding: 6px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .input-with-toggle .toggle-pass:focus { outline: none; }
        
        .form-group input[type="text"]:focus,
        .form-group input[type="password"]:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .button-group {
            display: flex;
            gap: 12px;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 2px solid #e0e0e0;
        }
        
        .button-group button,
        .button-group a {
            flex: 1;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        
        .button-group button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .button-group button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .button-group button:active {
            transform: translateY(0);
        }
        
        .button-group a {
            background: #f0f0f0;
            color: #333;
            border: 2px solid #e0e0e0;
        }
        
        .button-group a:hover {
            background: #e8e8e8;
            border-color: #667eea;
            color: #667eea;
        }
        
        @media (max-width: 480px) {
            .password-content {
                padding: 25px 20px;
            }
            
            .button-group {
                flex-direction: column;
                gap: 10px;
            }
            
            .button-group button,
            .button-group a {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="password-card">
        <div class="password-header">
            <h3><i class="fa fa-lock"></i> Change Password</h3>
        </div>
        <div class="password-content">
            <form method="post" action="changePass.php">
                <div class="form-group">
                    <label><i class="fa fa-user"></i> Username</label>
                    <input type="text" name="uname" value="<?php echo isset($_SESSION['Username']) ? htmlspecialchars($_SESSION['Username']) : ''; ?>" required readonly aria-readonly="true" style="background:#f5f5f5;cursor:not-allowed;" />
                </div>
                <div class="form-group">
                    <label><i class="fa fa-key"></i> Current Password</label>
                    <div class="input-with-toggle">
                        <input type="password" id="currPass" name="currPass" required />
                        <button type="button" class="toggle-pass" data-target="currPass" aria-label="Show current password"><i class="fa fa-eye"></i></button>
                    </div>
                </div>
                <div class="form-group">
                    <label><i class="fa fa-shield"></i> New Password</label>
                    <div class="input-with-toggle">
                        <input type="password" id="newPass" name="newPass" required />
                        <button type="button" class="toggle-pass" data-target="newPass" aria-label="Show new password"><i class="fa fa-eye"></i></button>
                    </div>
                </div>
                <div class="form-group">
                    <label><i class="fa fa-check-circle"></i> Confirm New Password</label>
                    <div class="input-with-toggle">
                        <input type="password" id="conNewPass" name="conNewPass" required />
                        <button type="button" class="toggle-pass" data-target="conNewPass" aria-label="Show confirm password"><i class="fa fa-eye"></i></button>
                    </div>
                </div>
                <div class="button-group">
                    <button type="submit"><i class="fa fa-check"></i> Change Password</button>
                    <a href="../profileView.php"><i class="fa fa-times"></i> Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
<script>
    // Password show/hide toggle
    (function(){
        document.addEventListener('click', function(e){
            var btn = e.target.closest && e.target.closest('.toggle-pass');
            if(!btn) return;
            var targetId = btn.getAttribute('data-target');
            var inp = document.getElementById(targetId);
            if(!inp) return;
            if(inp.type === 'password'){
                inp.type = 'text';
                btn.innerHTML = '<i class="fa fa-eye-slash"></i>';
                btn.setAttribute('aria-pressed', 'true');
            } else {
                inp.type = 'password';
                btn.innerHTML = '<i class="fa fa-eye"></i>';
                btn.setAttribute('aria-pressed', 'false');
            }
        });
    })();
</script>
