<?php
// Get comments for a blog (used by React)
require 'db.php';
session_start();

header('Content-Type: application/json; charset=utf-8');

$blogId = isset($_GET['blogId']) ? intval($_GET['blogId']) : 0;

if ($blogId <= 0) {
    echo json_encode(['ok' => false, 'error' => 'invalid_blog_id']);
    exit;
}

$sql = "SELECT blogId, comment, commentUser, commentPic, commentTime FROM blogfeedback WHERE blogId = $blogId ORDER BY commentTime DESC";
$result = mysqli_query($conn, $sql);

$comments = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $comments[] = [
            'id' => md5($row['blogId'] . $row['commentTime']),
            'blogId' => (int)$row['blogId'],
            'comment' => htmlspecialchars($row['comment']),
            'commentUser' => htmlspecialchars($row['commentUser']),
            'commentPic' => htmlspecialchars($row['commentPic']),
            'commentTime' => date('g:i a', strtotime($row['commentTime']))
        ];
    }
}

echo json_encode(['ok' => true, 'comments' => $comments]);
exit;
?>
