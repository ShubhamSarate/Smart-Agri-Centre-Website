// React client disabled
// File replaced to remove the React client. No runtime code here.
export default {};
