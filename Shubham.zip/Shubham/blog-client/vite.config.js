// Vite config removed — React client disabled.
// This file left as a placeholder to avoid altering repo structure.
export default {};
