# Blog Client (React + Vite)

This is a React frontend for the blog comments/likes using Vite.

## Setup & Development

### Install dependencies
```powershell
# Blog Client (disabled)

The React blog client has been disabled and its runtime files replaced with placeholders.
If you need to restore the client, check your version control history for the original files.

The site no longer depends on this client. Keep or remove this folder as you prefer.
## How it works

- `src/main.jsx` mounts the Comments component to `#root`.
- `src/components/Comments.jsx` fetches and displays comments, posts new ones via `/ajax_comment.php`.
- The main `blogView.php` includes a `<div id="comments-root" data-blogid="..."></div>` mountpoint.
- After build, include `dist/comments.bundle.js` on the PHP page to mount the React app.

## Integration with PHP

Update `blogView.php`:
1. Replace the old comments HTML section with:
   ```html
   <div id="comments-root" data-blogid="<?= $id ?>"></div>
   <script src="/Shubham/js/comments.bundle.js" defer></script>
   ```
2. The React app will handle comments rendering and form submission.

## Fallback

If React fails to load or build, the original form (`<form method="post">`) still works for users without JS.

## TODO

- [ ] Copy `dist/comments.bundle.js` to `/js/comments.bundle.js` after build.
- [ ] Test on production URL.
- [ ] Add likes component.
