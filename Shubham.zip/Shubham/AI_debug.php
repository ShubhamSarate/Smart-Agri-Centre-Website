<?php
// AI debug removed — not used by the live site anymore.
// Redirect to admin dashboard.
session_start();
header('Location: adminDashboard.php');
exit();
?>
