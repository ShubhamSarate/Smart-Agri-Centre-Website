<?php
// Legacy analysis runner removed. Redirecting to admin dashboard.
session_start();
header('Location: adminDashboard.php');
exit();
?>